package com.example.test.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.dto.StreamRequest;
import com.example.test.model.ConfigData;
import com.example.test.model.StreamData;

@RestController
@RequestMapping(value = "/api")
public class StreamController {

	public static final String WARNING_TYPE = "Warning";
	public static final String CRITICAL_TYPE = "Critical";
	public static final String INFO_TYPE = "Info";

	@PostMapping(value = "/get-stream")
	public ResponseEntity<Object> getStream(@RequestBody StreamRequest request) throws Exception {
		try {

			// creating streamdata Class Db
			List<StreamData> streamDB = new ArrayList<>();

			StreamData warningData = new StreamData();
			warningData.setId(1L);
			warningData.setType(WARNING_TYPE);
			warningData.setCount(0L);

			StreamData infoData = new StreamData();
			infoData.setId(2L);
			infoData.setType(INFO_TYPE);
			infoData.setCount(0L);

			StreamData criticalData = new StreamData();
			criticalData.setId(3L);
			criticalData.setType(CRITICAL_TYPE);
			criticalData.setCount(0L);

			streamDB.add(warningData);
			streamDB.add(infoData);
			streamDB.add(criticalData);

			// creating config table data

			List<ConfigData> configData = new ArrayList<>();

			ConfigData warning = new ConfigData();
			warning.setId(1L);
			warning.setType(WARNING_TYPE);
			warning.setFrequency(10L);
			warning.setDuration(100L);
			warning.setWaitTime(100L);

			ConfigData info = new ConfigData();
			info.setId(2L);
			info.setType(INFO_TYPE);
			info.setFrequency(10L);
			info.setDuration(100L);
			info.setWaitTime(100L);

			ConfigData critical = new ConfigData();
			critical.setId(1L);
			critical.setType(CRITICAL_TYPE);
			critical.setFrequency(10L);
			critical.setDuration(100L);
			critical.setWaitTime(100L);

			if (request.getType().equalsIgnoreCase(WARNING_TYPE)) {

				warningFunction(streamDB);
			}

			else if (request.getType().equalsIgnoreCase(INFO_TYPE)) {

				StreamData infoDb = streamDB.get(1);
				infoDb.setCount(infoDb.getCount() + 1);
				streamDB.set(1, infoDb);
			}

			else {
				StreamData cirticalDb = streamDB.get(2);
				cirticalDb.setCount(cirticalDb.getCount() + 1);
				streamDB.set(2, cirticalDb);
			}

		}

		catch (Exception e) {
			throw e;
		}

		return null;

	}

	private void warningFunction(List<StreamData> streamDB) {

		StreamData warningDb = streamDB.get(0);
		Long prevCount = warningDb.getCount();
		if (prevCount == 0L) {
			warningDb.setTime(new Date());
		}
		warningDb.setCount(prevCount + 1);

		streamDB.set(0, warningDb);

	}

}
